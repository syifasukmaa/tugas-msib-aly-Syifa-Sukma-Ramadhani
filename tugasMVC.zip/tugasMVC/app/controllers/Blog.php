<?php
class Blog extends Controller
{


  public function index()
  {
    $data["judul"] = "Blog";
    $data["blog"] = $this->model("Blog_model")->getAllBlog();
    $this->view("templates/header", $data);
    $this->view("blog/index", $data);
    $this->view("templates/footer");
  }
  public function detail($id)
  {
    $path = $_SERVER['REQUEST_URI'];
    $segments = explode('/', trim($path, '/'));
    $id = end($segments);
    $id_data = intval($id);

    $data["judul"] = "Detail Blog";
    $data["blog"] = $this->model("Blog_model")->getBlogById($id_data);
    $this->view("templates/header", $data);
    $this->view("blog/detail", $data);
    $this->view("templates/footer");
  }
  public function tambah()
  {
    if ($this->model("Blog_model")->buatArtikel($_POST) > 0) {
      Flasher::setFlash("berhasil", "ditambahkan", "success");
      header("Location: " . BASE_URL . "/blog");
      exit;
    } else {
      Flasher::setFlash("gagal", "ditambahkan", "danger");
      header("Location: " . BASE_URL . "/blog");
      exit;
    }
  }
  public function hapus($id)
  {
    $path = $_SERVER['REQUEST_URI'];
    $segments = explode('/', trim($path, '/'));
    $id = end($segments);
    $id_data = intval($id);

    if ($this->model("Blog_model")->hapusArtikel(["id" => $id_data]) > 0) {
      Flasher::setFlash("berhasil", "dihapus", "success");
    } else {
      Flasher::setFlash("gagal", "dihapus", "danger");
    }
    header("Location: " . BASE_URL . "/blog");
    exit;
  }
  public function edit()
  {
    $path = $_SERVER['REQUEST_URI'];
    $segments = explode('/', trim($path, '/'));
    $id = end($segments);
    $id_data = intval($id);

    $data = [
      'id' => $id_data,
      'judul' => $_POST['judul'],
      'tulisan' => $_POST['tulisan'],
      'penulis' => $_POST['penulis'],
    ];

    if ($this->model("Blog_model")->editArtikel($data) > 0) {
      Flasher::setFlash("berhasil", "mengedit", "success");
    } else {
      Flasher::setFlash("gagal", "mengedit", "danger");
    }

    header("Location: " . BASE_URL . "/blog/detail/{$id_data}");
    exit;
  }
}
