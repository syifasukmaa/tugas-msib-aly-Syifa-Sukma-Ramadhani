<?php
class Admin extends Controller
{

  public function index()
  {
    $data["judul"] = "Admin PPDB Siwa";
    $data["biodata"] = $this->model("Admin_model")->getAllBlog();
    $this->view("templates/sidebar");
    $this->view("templates/header");
    $this->view("admin/index", $data);
    $this->view("templates/footer");
  }
  // public function detail($id)
  // {
  //   $path = $_SERVER['REQUEST_URI'];
  //   $segments = explode('/', trim($path, '/'));
  //   $id = end($segments);
  //   $id_data = intval($id);

  //   $data["judul"] = "Detail Blog";
  //   $data["blog"] = $this->model("Blog_model")->getBlogById($id_data);
  //   $this->view("templates/header", $data);
  //   $this->view("blog/detail", $data);
  //   $this->view("templates/footer");
  // }
}
