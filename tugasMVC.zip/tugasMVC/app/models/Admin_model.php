<?php

class Admin_model
{
  private $table = "biodata";
  private $table_sekolah = "sekolah";
  private $db;
  public function __construct()
  {
    $this->db = new Database;
    //data source name
  }

  public function getAllBlog()
  {
    $this->db->query("SELECT * FROM " . $this->table);
    return $this->db->resultAll();
  }
}
