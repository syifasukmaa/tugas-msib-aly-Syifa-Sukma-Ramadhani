<?php
class Blog_model
{
  private $table = "blog";
  private $db;
  public function __construct()
  {
    $this->db = new Database;
    //data source name
  }

  public function getAllBlog()
  {
    $this->db->query("SELECT * FROM " . $this->table);
    return $this->db->resultAll();
  }

  public function getBlogById($id)
  {
    $this->db->query("SELECT * FROM " . $this->table . ' WHERE id=:id');
    $this->db->bind('id', $id);
    $result = $this->db->resultSingle();
    return $result;
  }
  public function buatArtikel($data)
  {
    $query = "INSERT INTO blog VALUES
    ('', :judul, :tulisan, :penulis)";
    $this->db->query($query);
    $this->db->bind("judul", $data["judul"]);
    $this->db->bind("tulisan", $data["tulisan"]);
    $this->db->bind("penulis", $data["penulis"]);
    $this->db->execute();
    return $this->db->rowCount();
  }

  public function hapusArtikel($data)
  {
    $query = "DELETE FROM blog where id=:id";
    $this->db->query($query);
    $this->db->bind("id", $data["id"]);
    $this->db->execute();
    return $this->db->rowCount();
  }
  public function editArtikel($data)
  {
    $query = "UPDATE blog SET
    judul = :judul,
    tulisan = :tulisan,
    penulis = :penulis
    WHERE id = :id";

    $this->db->query($query);
    $this->db->bind("id", $data["id"]);
    $this->db->bind("judul", $data["judul"]);
    $this->db->bind("tulisan", $data["tulisan"]);
    $this->db->bind("penulis", $data["penulis"]);
    $this->db->execute();

    return $this->db->rowCount();
  }
}
