<div class="container mt-5">
  <?php Flasher::flash(); ?>
  <div class="card" style="width: 18rem;">
    <div class="card-body">
      <?php if ($data["blog"]) : ?>
        <h5 class="card-title"><?= $data['blog']['judul']; ?></h5>
        <h6 class="card-subtitle mb-2 text-muted"><?= $data['blog']['penulis']; ?></h6>
        <p class="card-text"><?= $data['blog']['tulisan']; ?></p>
      <?php else : ?>
        <p>Blog tidak ditemukan.</p>
      <?php endif; ?>
      <a href="<?= BASE_URL; ?>/blog" class="card-link">Kembali</a>
      <button type="button" class="badge text-bg-primary" data-bs-toggle="modal" data-bs-target="#exampleModal">
        Edit Artikel
      </button>
    </div>
  </div>
</div>

<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="judulModal">Edit Artikel</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="<?= BASE_URL; ?>/blog/edit/<?= $data['blog']['id']; ?>" method="post">
          <div class="form-group">
          </div>
          <div class="form-group">
            <label for="judul">Judul Artikel</label>
            <input type="text" class="form-control" id="judul" value="<?= $data['blog']['judul']; ?>" name="judul">
          </div>
          <div class="form-group">
            <label for="tulisan">Isi Artikel</label>
            <textarea class="form-control" id="tulisan" rows="5" name="tulisan"><?= $data['blog']['tulisan']; ?></textarea>
          </div>
          <div class="form-group">
            <label for="penulis">Nama Penulis</label>
            <input type="text" class="form-control" id="penulis" value="<?= $data['blog']['penulis']; ?>" name="penulis">
          </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Edit Artikel</button>
      </div>
      </form>
    </div>
  </div>