<!-- Page body -->
<div class="px-3">

  <div class="card">
    <div class="table-responsive">
      <table class="table table-vcenter card-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Jenis Kelamin</th>
            <th>Email Ortu</th>
            <th>Asal Sekolah</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($data["biodata"] as $biodata) : ?>
            <tr>
              <td>
                <?= $biodata["nama"]; ?>
              </td>
              <td>
                <?= $biodata["jenis_kelamin"]; ?>
              </td>
              <td>
                <?= $biodata["email_ortu"]; ?>
              </td>
              <td>
                <?= $biodata["asal_sekolah"]; ?>
              </td>
              <td>
                <a style="margin-bottom: 2px;" class="btn btn-success btn-sm" href="{{ route('students.edit', $student->id) }}">Edit</a>
                <form action="{{ route('students.destroy', $student->id) }}" method="post">
                  <input type="submit" value="Hapus" class="btn btn-danger btn-sm">
                </form>
              </td>
            </tr>
          <?php endforeach; ?>

        </tbody>
      </table>
    </div>
  </div>
</div>